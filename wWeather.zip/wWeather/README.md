# SpeechRecognizer
#### Android开发-在Android项目里集成讯飞语音识别与合成的实现
详情说明请看我的CSDN博客：https://blog.csdn.net/fukaimei/article/details/78499311
