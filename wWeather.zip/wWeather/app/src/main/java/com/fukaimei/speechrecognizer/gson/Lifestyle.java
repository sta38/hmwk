package com.fukaimei.speechrecognizer.gson;

import com.google.gson.annotations.SerializedName;

public class Lifestyle {

    @SerializedName("type")
    public String sugtype;

    @SerializedName("brf")
    public String sugbrf;

    @SerializedName("txt")
    public String sugtxt;

}
