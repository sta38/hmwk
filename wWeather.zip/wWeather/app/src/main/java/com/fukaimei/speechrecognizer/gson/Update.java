package com.fukaimei.speechrecognizer.gson;

import com.google.gson.annotations.SerializedName;

/**
 * Created by YangJianlin on 2020/3/14.
 */

public class Update {
    @SerializedName("loc")
    public String updateTime;
}
